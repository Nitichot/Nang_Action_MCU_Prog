#include "MPU6050_Madgwick.h"
#include "BLE_Manager.h"
#include <esp_task_wdt.h> 

#define ENABLE_SERIAL_PLOTTER 1 
#define ENABLE_CALIBRATION false 

#define SDA_PIN 6
#define SCL_PIN 7

MPU_Sensor mpu1;
MPU_Sensor mpu2;
IMU_BLE_Data bleData;

hw_timer_t * timer = NULL;
volatile bool dataReady = false;

void IRAM_ATTR onTimer() {
  dataReady = true;
}

void setup() {
  Serial.begin(115200);
  delay(1000); 

  Serial.println("=========================================");
  Serial.println("System Booting...");
  Serial.println("Please KEEP SENSOR STILL for Calibration.");
  Serial.println("=========================================");

  // 1. เริ่มต้นและ Calibrate MPU6050 ก่อน (ใช้เวลาช่วงนี้ในการนิ่ง)
  Serial.println("Init MPU 1 (Addr: 0x68)...");
  MPU_Init(mpu1, Wire, 0x68, SDA_PIN, SCL_PIN, ENABLE_CALIBRATION);
  
  Serial.println("Init MPU 2 (Addr: 0x69)...");
  MPU_Init(mpu2, Wire, 0x69, SDA_PIN, SCL_PIN, ENABLE_CALIBRATION);

  // 2. หน่วงเวลาเพิ่มเติมเพื่อให้ครบ 15 วินาที (ให้เซ็นเซอร์นิ่งสนิท 100%)
  // เนื่องจาก MPU_Init มีการดีเลย์ระหว่างเก็บ 500 Samples ไปส่วนหนึ่งแล้ว 
  // ตรงนี้เราจึงใส่ Delay เพิ่มเติมให้ครบตามเวลาที่ต้องการ
  Serial.println("Calibration completed. Stabilizing sensor for 30 seconds...");
  for (int i = 30; i > 0; i--) {
    Serial.print(i); Serial.println(" seconds remaining...");
    delay(1000);
  }

  // 3. หลังจากครบเวลา ค่อยเริ่มเปิด BLE Server ให้เชื่อมต่อได้
  Serial.println("Starting BLE Server...");
  BLE_Init();

  #if ENABLE_SERIAL_PLOTTER
    Serial.println("Roll1,Pitch1,Yaw1,Roll2,Pitch2,Yaw2");
  #endif

  // ตั้งค่า Task Watchdog Timer
  esp_task_wdt_config_t wdt_config = {
      .timeout_ms = 3000,
      .idle_core_mask = (1 << portNUM_PROCESSORS) - 1, 
      .trigger_panic = true
  };
  esp_task_wdt_init(&wdt_config);
  esp_task_wdt_add(NULL);

  // ตั้งค่า Hardware Timer (400Hz)
  timer = timerBegin(1000000); 
  timerAttachInterrupt(timer, &onTimer);
  timerAlarm(timer, 2500, true, 0); 
  
  Serial.println("System Ready & BLE Advertising Started!");
}

void loop() {
  esp_task_wdt_reset(); 
  BLE_HandleConnection();

  if (dataReady) {
    dataReady = false; 

    MPU_Update(mpu1);
    MPU_Update(mpu2);

    bleData.roll1  = mpu1.roll;
    bleData.pitch1 = mpu1.pitch;
    bleData.yaw1   = mpu1.yaw;
    
    bleData.roll2  = mpu2.roll;
    bleData.pitch2 = mpu2.pitch;
    bleData.yaw2   = mpu2.yaw;

    BLE_SendData(bleData);

    #if ENABLE_SERIAL_PLOTTER
      Serial.print(bleData.roll1);  Serial.print(",");
      Serial.print(bleData.pitch1); Serial.print(",");
      Serial.print(bleData.yaw1);   Serial.print(",");
      Serial.print(bleData.roll2);  Serial.print(",");
      Serial.print(bleData.pitch2); Serial.print(",");
      Serial.println(bleData.yaw2);
    #endif
  }
}