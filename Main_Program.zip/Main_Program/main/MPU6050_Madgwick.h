#ifndef MPU6050_MADGWICK_H
#define MPU6050_MADGWICK_H

#include <Wire.h>
#include <MadgwickAHRS.h>

#define TUNE_MADGWICK_BETA 0.05
#define TUNE_ACCEL_DEADZONE 0.05
#define TUNE_VELOCITY_DAMPING 0.90
#define TUNE_CALIB_SAMPLES 500

struct MPU_Sensor {
  TwoWire *wire;
  uint8_t addr; 
  Madgwick filter; 
  
  float bias_AcX = 0, bias_AcY = 0, bias_AcZ = 0;
  float bias_GyX = 0, bias_GyY = 0, bias_GyZ = 0;
  
  float roll = 0, pitch = 0, yaw = 0;
  float posX = 0, posY = 0, posZ = 0;
  float velX = 0, velY = 0, velZ = 0;
  
  unsigned long prevTime = 0;
};

void MPU_Init(MPU_Sensor &sensor, TwoWire &w, uint8_t address, int sda, int scl, bool calibrate) {
  sensor.wire = &w;
  sensor.addr = address;
  
  w.begin(sda, scl);
  w.setClock(400000); 
  w.setTimeOut(10);   
  
  w.beginTransmission(sensor.addr);
  w.write(0x6B); w.write(0x00); 
  w.endTransmission(true);
  delay(50);

  w.beginTransmission(sensor.addr);
  w.write(0x1C); w.write(0x00); 
  w.endTransmission(true);
  w.beginTransmission(sensor.addr);
  w.write(0x1B); w.write(0x00); 
  w.endTransmission(true);

  if (calibrate) {
    long sumAcX = 0, sumAcY = 0, sumAcZ = 0;
    long sumGyX = 0, sumGyY = 0, sumGyZ = 0;
    
    for (int i = 0; i < TUNE_CALIB_SAMPLES; i++) {
      w.beginTransmission(sensor.addr);
      w.write(0x3B);
      w.endTransmission(false);
      w.requestFrom((uint16_t)sensor.addr, (uint8_t)14, true);
      
      if(w.available() == 14) {
          sumAcX += w.read()<<8 | w.read();  
          sumAcY += w.read()<<8 | w.read();  
          sumAcZ += w.read()<<8 | w.read();  
          w.read()<<8 | w.read(); 
          sumGyX += w.read()<<8 | w.read();  
          sumGyY += w.read()<<8 | w.read();  
          sumGyZ += w.read()<<8 | w.read();  
      }
      delay(2);
    }
    
    sensor.bias_AcX = (float)sumAcX / TUNE_CALIB_SAMPLES;
    sensor.bias_AcY = (float)sumAcY / TUNE_CALIB_SAMPLES;
    sensor.bias_AcZ = ((float)sumAcZ / TUNE_CALIB_SAMPLES) - 16384.0; 
    
    sensor.bias_GyX = (float)sumGyX / TUNE_CALIB_SAMPLES;
    sensor.bias_GyY = (float)sumGyY / TUNE_CALIB_SAMPLES;
    sensor.bias_GyZ = (float)sumGyZ / TUNE_CALIB_SAMPLES;
  }
  
  sensor.filter.begin(400.0); 
  sensor.prevTime = micros();
}

void MPU_Update(MPU_Sensor &sensor) {
  sensor.wire->beginTransmission(sensor.addr);
  sensor.wire->write(0x3B);
  sensor.wire->endTransmission(false);
  sensor.wire->requestFrom((uint16_t)sensor.addr, (uint8_t)14, true);
  
  if(sensor.wire->available() == 14) {
    int16_t rawAcX = sensor.wire->read()<<8 | sensor.wire->read();  
    int16_t rawAcY = sensor.wire->read()<<8 | sensor.wire->read();  
    int16_t rawAcZ = sensor.wire->read()<<8 | sensor.wire->read();  
    sensor.wire->read()<<8 | sensor.wire->read();  
    int16_t rawGyX = sensor.wire->read()<<8 | sensor.wire->read();  
    int16_t rawGyY = sensor.wire->read()<<8 | sensor.wire->read();  
    int16_t rawGyZ = sensor.wire->read()<<8 | sensor.wire->read();  

    unsigned long currentTime = micros();
    float dt = (currentTime - sensor.prevTime) / 1000000.0;
    sensor.prevTime = currentTime;
    
    if(dt > 0) sensor.filter.begin(1.0 / dt); 

    float raw_ax = (rawAcX - sensor.bias_AcX) / 16384.0;
    float raw_ay = (rawAcY - sensor.bias_AcY) / 16384.0;
    float raw_az = (rawAcZ - sensor.bias_AcZ) / 16384.0;

    float raw_gx = (rawGyX - sensor.bias_GyX) / 131.0;
    float raw_gy = (rawGyY - sensor.bias_GyY) / 131.0;
    float raw_gz = (rawGyZ - sensor.bias_GyZ) / 131.0;

    sensor.filter.updateIMU(raw_gx, raw_gy, raw_gz, raw_ax, raw_ay, raw_az);

    sensor.roll  = sensor.filter.getRoll();
    sensor.pitch = sensor.filter.getPitch();
    sensor.yaw   = sensor.filter.getYaw();

    float p_rad = sensor.pitch * PI / 180.0;
    float r_rad = sensor.roll * PI / 180.0;

    float grav_x = -sin(p_rad);
    float grav_y = cos(p_rad) * sin(r_rad);
    float grav_z = cos(p_rad) * cos(r_rad);

    float lin_ax = (raw_ax - grav_x) * 9.81;
    float lin_ay = (raw_ay - grav_y) * 9.81;
    float lin_az = (raw_az - grav_z) * 9.81;

    float acc_mag = sqrt(lin_ax*lin_ax + lin_ay*lin_ay + lin_az*lin_az);

    if (acc_mag < TUNE_ACCEL_DEADZONE * 9.81) {
      lin_ax = 0;
      lin_ay = 0;
      lin_az = 0;
      sensor.velX = 0;
      sensor.velY = 0;
      sensor.velZ = 0;
    } else {
      sensor.velX *= 0.90; 
      sensor.velY *= 0.90;
      sensor.velZ *= 0.90;
    }

    sensor.velX += lin_ax * dt;
    sensor.velY += lin_ay * dt;
    sensor.velZ += lin_az * dt;

    float vel_mag = sqrt(sensor.velX*sensor.velX + sensor.velY*sensor.velY + sensor.velZ*sensor.velZ);

    if (vel_mag < TUNE_ACCEL_DEADZONE * 9.81) {
      sensor.velX = 0;
      sensor.velY = 0;
      sensor.velZ = 0;
    } else {
      sensor.posX *= 0.90; 
      sensor.posY *= 0.90;
      sensor.posZ *= 0.90;
    }

    sensor.posX += sensor.velX * dt;
    sensor.posY += sensor.velY * dt;
    sensor.posZ += sensor.velZ * dt;
  }
}

void MPU_ResetPosition(MPU_Sensor &sensor) {
  sensor.posX = 0;
  sensor.posY = 0;
  sensor.posZ = 0;
  sensor.velX = 0;
  sensor.velY = 0;
  sensor.velZ = 0;
}

#endif